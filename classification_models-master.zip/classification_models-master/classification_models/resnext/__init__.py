import warnings
from .models import *

warnings.warn('Current ResNext models are deprecated, '
              'use keras.applications ResNeXt models')
